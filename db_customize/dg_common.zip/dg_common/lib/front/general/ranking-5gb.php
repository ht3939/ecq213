<?php
	for ($i=1; $i < 11 ; $i++) :
?>

<?php if($i<=3){
		echo "<tr class=\"js-ranking-item rank".$i."\">";
	}else{
		echo "<tr class=\"js-ranking-item\">";
	}
?>
	<td class="rank-num">
		<span class="rank">
		<?php if($i<=3){
				echo "<img src=\"./img/common/rank".$i."-L.png\" alt=\"".$i."位\">";
			}else{
				echo "<span class=\"rank-4more\">".$i."位</span>";
			}
		?>
		</span>
	</td>

 	<td class="rank-service">
		<div class="td-inner">
			<div class="logo"><img src="./img/index/Yahoo-wifi-logo.png" alt="Yahoo!JAPAN Wi-Fi"></div>
			<div class="title">
				<p>Y!Fi2年間ずーっと<br>得するプラン(4G)</p>
			</div>
		</div>
	</td>

	<td class="rank-name">
		<div class="td-inner">
			<div class="pic-outer">
				<ul class="pic bxslider">
					<li>
					<img src="<?php echo SITE_ROOT_DIR; ?>img/item/w01.png" alt="">
					<div class="status">
						<p class="name"><span>Huawei</span><br>Speed Wi-Fi NEXT W01</p>
					</div>
					</li>
					<li>
						<img src="<?php echo SITE_ROOT_DIR; ?>img/item/w01.png" alt="">
						<div class="status">
							<p class="name"><span>Huawei</span><br>Speed Wi-Fi NEXT W01</p>
						</div>
					</li>
					<li>
						<img src="<?php echo SITE_ROOT_DIR; ?>img/item/w01.png" alt="">
						<div class="status">
							<p class="name"><span>Huawei</span><br>Speed Wi-Fi NEXT W01</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</td>

	<td <?php if($i>3){echo "class=\"rank-price\"";}else{echo "class=\"rank-price r".$i."\"";}?>>
		<div class="td-inner w140"><span>2,480</span>円</div>
	</td>

	<td class="rank-data">
		<div class="td-inner w110">
		<span><span class="num">7</span><span class="gb">GB</span></span>/月<span class="speed">110Mbps</span>
		</div>
	</td>

	<td class="rank-conditions">
		<div class="td-inner"><span class="head ptn1">主な特典</span><br>
		<span class="text-ptn1">Yahoo! プレミアム会員（月額462円/税別）が必要</span><br>
		<span class="head ptn2">注意事項</span><br>
		<span class="text-ptn2">プレミアム会員必須<br>※３日で３GB制限あり</span>
		</div>
	</td>

	<td class="rank-company">
		<div class="td-inner w110">
			<p class="site_btn"><a href="http://wifi.yahoo.co.jp/campaign/plan" target="_blank">詳細を見る</a></p>
			<div class="site-link"><a href="http://wifi.yahoo.co.jp/" target="_blank"><img src="img/common/icon-yahoo.png" alt="">Yahoo! Wi-Fi</a><?php if($i>=2){echo "<span class=\"outer-site\">(外部サイトへ)</span>";} ?></div>
		</div>
	</td>
</tr>
<?php endfor; ?>
