<?php
/*
# 一般的なページのグローバルナビゲーション
*/
?>
<nav>
	<div id="gnav">
		<div class="base-container">
			グローバルナビゲーション
		</div>
	</div>
</nav>