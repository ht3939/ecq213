<?php
/*
# 一般的なページのヘッダー

<?php if(is_toppage()): ?>
<?php else: ?>
<?php endif; ?>

*/
?>
<header>
	<div id="header">
		<div class="base-container">
			<h1 class="header_logo-left"><a href="<?php echo SITE_ROOT_DIR; ?>"><img src="<?php echo SITE_ROOT_DIR; ?>img/header/logo.png" alt="格安モバイルルーター比較"></a></h1>
			<p class="header_logo-right"><a href="#"><img src="http://i.yimg.jp/c/logo/f/2.0/kainavi.search_r_34.png" alt="YAHOO!JAPAN! 買い物ナビゲーター"></a></p>
		</div>
	</div>
</header>

<div id="mainv">
	<div class="base-container">
		<img src="<?php echo SITE_ROOT_DIR; ?>img/header/mainv.png" alt="一番安い！がすぐ分かる！">
	</div>
</div>