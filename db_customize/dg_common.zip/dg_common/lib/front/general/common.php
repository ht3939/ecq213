<?php
/*
# 一般的なページ共通のインクルードファイル
*/



$this_dir = dirname(__FILE__);
// include_once($this_dir.'/header.php');
// include_once($this_dir.'/gnav.php');
// include_once($this_dir.'/sidebar.php');
// include_once($this_dir.'/footer.php');



?>