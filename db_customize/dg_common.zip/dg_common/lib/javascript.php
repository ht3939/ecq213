<?php
# 一般的なページの共通のJavaScript
?>
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo SITE_ROOT_DIR; ?>js/jquery-1.11.3.min.js"><\/script>');</script>
<script src="/js/front/common.js"></script>

<!--[if lt IE 9]>
<script src="/js/front/html5shiv.js"></script>
<![endif]-->
